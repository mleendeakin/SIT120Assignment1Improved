<template>
    <footer>
      <p>
        Made By: Michael Leen<br />
        <a href="mleen@deakin.edu.au">Contact: mleen@deakin.edu.au</a>
      </p>
    </footer>
</template>


<style>
    /* footer */

footer {
  text-align: center;
  position: fixed;
  width: 100%;
  padding: 3px;
  background-color: #7aac5b;
  color: white;
  bottom: 0;
  /* margin-bottom: auto; */
}

@media (max-width: 1000px) {
  footer {
    height: 5%;
    font-size: 12px;
  }
}
</style>