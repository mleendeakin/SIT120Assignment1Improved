<template>
    <div class="search">
      <input type="text" placeholder="Search.." class="search-bar" />
    </div>
</template>